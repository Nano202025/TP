package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Patios {
	double x;
	double y;
	double angulo;
	double escala;
	Image imagen;
	Image imagenFondo;
	
	
public Patios(int x, int y, String archivo) {
		
		this.x = x;
		this.y = y;
		this.angulo=0;
		this.escala=1.6;
		imagen = Herramientas.cargarImagen(archivo);
		imagenFondo = Herramientas.cargarImagen("Pasto (2).png");
		

}public void dibujarse(Entorno entorno)
{
	entorno.dibujarImagen(imagen, this.x, this.y, this.angulo, this.escala);
				
}



}
